from django.shortcuts import render,redirect
from .models import ToDoList,Category,Note
from .forms import NoteForm
from django.contrib import messages
# Create your views here.
def index(request):
    ToDos = ToDoList.objects.all()
    catogories = Category.objects.all()
    err_msg = ''
    message = ''
    message_class=''

    if request.method == 'POST':
       
        if "taskAdd" in request.POST:
            title = request.POST["description"]
            category = request.POST["category_select"]
            date = str(request.POST["date"])
            content = title + "--" + date + "--" + category
            
            
            ToDo = ToDoList(
                title = title,
                content = content,
                due_date = date,
                category = Category.objects.get(name=category),
                )
            ToDo.save()
            message = "Task added successfully"
            return for_Add(request) 
            #return redirect("/")

        if "taskDelete" in request.POST: 
            if "checkedbox" not in request.POST:
                message = 'Select one Task atleast'                
                return for_delete(request)
            else:
                checkedlist = request.POST["checkedbox"] 
            
                
                for todo_id in checkedlist:
                    todo = ToDoList.objects.get(id=int(todo_id)) 
                    todo.delete() 
                if checkedlist != 0:
                    message = 'Task Deleted successfully'
                    message_class = 'info'
        

    return render(request,"index.html",{"ToDos" : ToDos,"catogories" : catogories, "message" : message , "message_class": message_class})




def note(request):
    Notes = Note.objects.all()
    form = NoteForm(request.POST ,request.FILES or None)
    if form.is_valid():
        form.save()
                    
    if request.method == 'POST':
        if "taskDelete" in request.POST:
            checkboxlist = request.POST["checkedbox1"]

            for todo_id in checkboxlist:
                todo = Note.objects.get(id=int(todo_id))
                todo.delete()

    context = {'Notes':Notes,'form':form}
    return render(request,"note.html",context)

def del_note(request, note_id):

    Note.objects.get(id = note_id).delete() 
  
    return redirect("Note")   
        
  
def for_Add(request):
    ToDos = ToDoList.objects.all()
    catogories = Category.objects.all()
    message = "Task added successfully"
    if message:
        message_class = "success"
    context = {"ToDos" : ToDos,
               "catogories" : catogories, 
               "message" : message , 
               "message_class": message_class
               }
        
    return render(request,"index.html",context)

def for_delete(request):
    ToDos = ToDoList.objects.all()
    catogories = Category.objects.all()
    message = 'Select one Task atleast'
    if message:
        message_class = 'danger'
    context = {"ToDos" : ToDos,
               "catogories" : catogories, 
               "message" : message , 
               "message_class": message_class
               }
        
    return render(request,"index.html",context)