from django.db import models
from django.utils import timezone
from django import forms
# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        verbose_name = ("Category")
        verbose_name_plural = ("Categories")
    def __str__(self):
        return self.name

class ToDoList(models.Model):
    title = models.CharField(max_length=200)
    content = models.CharField(max_length=500)
    created_on = models.DateField(default=timezone.now().strftime("%Y-%m-%d"))
    due_date = models.DateField(default=timezone.now().strftime("%Y-%m-%d"))
    category = models.ForeignKey(Category,on_delete=models.DO_NOTHING,default="general",null=True, blank=True)
    
    class Meta:
      ordering = ["-created_on"]
    def __str__(self):
        return self.title

class Note(models.Model):
    Title = models.CharField(max_length=100)
    text = models.TextField(max_length = 250)
    img = models.ImageField(upload_to='pics',height_field=None, width_field=None, max_length=100,blank=True, null=True)

    created = models.DateTimeField(auto_now_add = True)

    class Meta:
        verbose_name = ("Note")
    def __str__(self):
        return self.text
