from django.contrib import admin
from .import models 
# Register your models here.
class ToDoListAdmin(admin.ModelAdmin):
    list_display = ("title" , "due_date", "created_on")

class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name",)

class NoteForm(admin.ModelAdmin):
    list_display = ("text",)


admin.site.register(models.ToDoList, ToDoListAdmin)
admin.site.register(models.Category, CategoryAdmin)
admin.site.register(models.Note,NoteForm)